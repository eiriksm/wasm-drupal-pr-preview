<?php

/**
 * @file
 * Generic transliteration data for the PhpTransliteration class.
 */

$base = [
  0x00 => 'lang', 'kan', 'lao', 'lai', 'xian', 'que', 'kong', 'chong', 'chong', 'ta', 'lin', 'hua', 'ju', 'lai', 'qi', 'min',
  0x10 => 'kun', 'kun', 'zu', 'gu', 'cui', 'ya', 'ya', 'gang', 'lun', 'lun', 'leng', 'jue', 'duo', 'zheng', 'guo', 'yin',
  0x20 => 'dong', 'han', 'zheng', 'wei', 'xiao', 'pi', 'yan', 'song', 'jie', 'beng', 'zu', 'ku', 'dong', 'zhan', 'gu', 'yin',
  0x30 => 'zi', 'ze', 'huang', 'yu', 'wai', 'yang', 'feng', 'qiu', 'yang', 'ti', 'yi', 'zhi', 'shi', 'zai', 'yao', 'e',
  0x40 => 'zhu', 'kan', 'lu', 'yan', 'mei', 'han', 'ji', 'ji', 'huan', 'ting', 'sheng', 'mei', 'qian', 'wu', 'yu', 'zong',
  0x50 => 'lan', 'ke', 'yan', 'yan', 'wei', 'zong', 'cha', 'sui', 'rong', 'ke', 'qin', 'yu', 'ti', 'lou', 'tu', 'dui',
  0x60 => 'xi', 'weng', 'cang', 'dang', 'rong', 'jie', 'kai', 'liu', 'wu', 'song', 'qiao', 'zi', 'wei', 'beng', 'dian', 'cuo',
  0x70 => 'qian', 'yong', 'nie', 'cuo', 'ji', 'shi', 'ruo', 'song', 'zong', 'jiang', 'liao', 'kang', 'chan', 'die', 'cen', 'ding',
  0x80 => 'tu', 'lou', 'zhang', 'zhan', 'zhan', 'ao', 'cao', 'qu', 'qiang', 'cui', 'zui', 'dao', 'dao', 'xi', 'yu', 'pei',
  0x90 => 'long', 'xiang', 'ceng', 'bo', 'qin', 'jiao', 'yan', 'lao', 'zhan', 'lin', 'liao', 'liao', 'jin', 'deng', 'duo', 'zun',
  0xA0 => 'jiao', 'gui', 'yao', 'jiao', 'yao', 'jue', 'zhan', 'yi', 'xue', 'nao', 'ye', 'ye', 'yi', 'nie', 'xian', 'ji',
  0xB0 => 'xie', 'ke', 'xi', 'di', 'ao', 'zui', 'wei', 'yi', 'rong', 'dao', 'ling', 'za', 'yu', 'yue', 'yin', 'ru',
  0xC0 => 'jie', 'li', 'gui', 'long', 'long', 'dian', 'rong', 'xi', 'ju', 'chan', 'ying', 'kui', 'yan', 'wei', 'nao', 'quan',
  0xD0 => 'chao', 'cuan', 'luan', 'dian', 'dian', 'nie', 'yan', 'yan', 'yan', 'kui', 'yan', 'chuan', 'kuai', 'chuan', 'zhou', 'huang',
  0xE0 => 'jing', 'xun', 'chao', 'chao', 'lie', 'gong', 'zuo', 'qiao', 'ju', 'gong', 'ju', 'wu', 'pu', 'pu', 'cha', 'qiu',
  0xF0 => 'qiu', 'ji', 'yi', 'si', 'ba', 'zhi', 'zhao', 'xiang', 'yi', 'jin', 'xun', 'juan', 'ba', 'xun', 'jin', 'fu',
];
