<?php

$test = \Drupal\Core\Url::fromRoute('gutenberg.reusable_blocks.update', ['block_id' => 1]);
$test2 = \Drupal\Core\Url::fromRoute('gutenberg.reusable_blocks.update', ['block_id' => 2]);
print_r([
  $test->toString(),
  $test2->toString(),
]);
