<?php


$items = \Drupal::service('cache.bootstrap')->get('module_implements')->data;
$filtered = array_filter($items, fn($k) => str_starts_with($k, 'form_commerce'), ARRAY_FILTER_USE_KEY);
## check if it contains items, that's bad!
var_dump($filtered);
